import tkinter as tk
from tkinter import ttk, messagebox
from utils import get_connection

class AdminForm:
    def __init__(self, root, ma_admin, login_win):
        self.root, self.login_win, self.ma_id = root, login_win, ma_admin
        self.root.title(f"Hệ Thống Quản Trị - Admin: {ma_admin}")
        self.root.geometry("1100x650")

        tk.Button(self.root, text="Đăng xuất", bg="red", fg="white",
                  font=("Arial", 10, "bold"), command=self.dang_xuat).pack(anchor="ne", padx=10, pady=5)

        self.tabs = ttk.Notebook(self.root)
        self.tabs.pack(fill=tk.BOTH, expand=True)

        self.tab_users = tk.Frame(self.tabs)
        self.tabs.add(self.tab_users, text="Quản lý Tài khoản")
        self.ui_quan_ly_taikhoan()

        self.tab_students = tk.Frame(self.tabs)
        self.tabs.add(self.tab_students, text="Quản lý Sinh viên")
        self.ui_quan_ly_sinhvien()

        self.tab_courses = tk.Frame(self.tabs)
        self.tabs.add(self.tab_courses, text="Môn học & Học phần")
        self.ui_quan_ly_hocphan()

    def dang_xuat(self):
        if messagebox.askyesno("Xác nhận", "Bạn có chắc chắn muốn đăng xuất?"):
            self.root.destroy()
            self.login_win.deiconify()

    def ui_quan_ly_taikhoan(self):
        f = tk.Frame(self.tab_users); f.pack(pady=10)
        tk.Label(f, text="Mã TK:").grid(row=0, column=0)
        self.ent_tk = tk.Entry(f); self.ent_tk.grid(row=0, column=1, padx=5)
        tk.Label(f, text="Vai trò:").grid(row=0, column=2)
        self.cb_vaitro = ttk.Combobox(f, values=["SinhVien", "GiangVien", "Admin"])
        self.cb_vaitro.grid(row=0, column=3, padx=5)

        self.tree_tk = ttk.Treeview(self.tab_users, columns=("id", "role"), show="headings")
        self.tree_tk.heading("id", text="Tên Tài Khoản")
        self.tree_tk.heading("role", text="Vai Trò")
        self.tree_tk.pack(fill=tk.BOTH, expand=True, padx=10)

        btn_f = tk.Frame(self.tab_users); btn_f.pack(pady=10)
        tk.Button(btn_f, text="Thêm mới", bg="green", fg="white", command=self.add_account).pack(side=tk.LEFT, padx=5)
        tk.Button(btn_f, text="Xóa tài khoản", bg="orange", command=self.delete_account).pack(side=tk.LEFT, padx=5)
        tk.Button(btn_f, text="Tải danh sách", bg="blue", fg="white", command=self.load_accounts).pack(side=tk.LEFT, padx=5)

    def load_accounts(self):
        for item in self.tree_tk.get_children(): self.tree_tk.delete(item)
        conn = get_connection()
        if conn:
            try:
                cursor = conn.cursor()
                cursor.execute("SELECT MaTK, VaiTro FROM TAIKHOAN")
                for row in cursor.fetchall(): self.tree_tk.insert("", tk.END, values=row)
            except Exception as e:
                messagebox.showerror("Lỗi", str(e))
            finally:
                conn.close()

    def add_account(self):
        u, r = self.ent_tk.get().strip(), self.cb_vaitro.get().strip()
        if not u or not r: return messagebox.showerror("Lỗi", "Nhập đủ thông tin")
        conn = get_connection()
        if conn:
            try:
                cursor = conn.cursor()
                cursor.execute("INSERT INTO TAIKHOAN (MaTK, PasswordHash, VaiTro) VALUES (?, '123456', ?)", (u, r))
                conn.commit()
                self.load_accounts()
            except Exception as e: messagebox.showerror("Lỗi", str(e))
            finally: conn.close()

    def delete_account(self):
        selected = self.tree_tk.selection()
        if not selected: return
        tk_id = self.tree_tk.item(selected[0])['values'][0]
        if not messagebox.askyesno("Xác nhận", f"Xóa tài khoản '{tk_id}'?"): return
        conn = get_connection()
        if conn:
            try:
                cursor = conn.cursor()
                cursor.execute("DELETE FROM TAIKHOAN WHERE MaTK=?", (tk_id,))
                conn.commit()
                self.load_accounts()
            except Exception as e: messagebox.showerror("Lỗi", str(e))
            finally: conn.close()

    def ui_quan_ly_sinhvien(self):
        f = tk.Frame(self.tab_students); f.pack(pady=10)
        tk.Label(f, text="Mã SV:").grid(row=0, column=0)
        self.ent_sv = tk.Entry(f); self.ent_sv.grid(row=0, column=1)
        tk.Label(f, text="Họ tên:").grid(row=0, column=2)
        self.ent_hoten = tk.Entry(f); self.ent_hoten.grid(row=0, column=3)

        self.tree_sv = ttk.Treeview(self.tab_students, columns=("1","2","3","4","5"), show="headings")
        for i, txt in enumerate(["Mã SV","Họ Tên","Ngày Sinh","Địa Chỉ","Mã Lớp"], 1):
            self.tree_sv.heading(str(i), text=txt)
            self.tree_sv.column(str(i), width=130)
        self.tree_sv.pack(fill=tk.BOTH, expand=True, padx=10)
        tk.Button(self.tab_students, text="Tải dữ liệu SV", command=self.load_students).pack(pady=5)

    def load_students(self):
        for item in self.tree_sv.get_children(): self.tree_sv.delete(item)
        conn = get_connection()
        if conn:
            try:
                cursor = conn.cursor()
                # ✅ Thêm MaLop — bảng SINHVIEN có cột này, bỏ GioiTinh cho gọn
                cursor.execute("SELECT MaSV, HoTen, NgaySinh, DiaChi, MaLop FROM SINHVIEN")
                for row in cursor.fetchall(): self.tree_sv.insert("", tk.END, values=row)
            except Exception as e: messagebox.showerror("Lỗi", str(e))
            finally: conn.close()

    def ui_quan_ly_hocphan(self):
        self.tree_hp = ttk.Treeview(self.tab_courses, columns=("1","2","3"), show="headings")
        for i, txt in enumerate(["Mã HP","Tên HP","Số Tín Chỉ"], 1):
            self.tree_hp.heading(str(i), text=txt)
        self.tree_hp.pack(fill=tk.BOTH, expand=True, padx=10)
        tk.Button(self.tab_courses, text="Tải dữ liệu HP", command=self.load_courses).pack(pady=5)

    def load_courses(self):
        for item in self.tree_hp.get_children(): self.tree_hp.delete(item)
        conn = get_connection()
        if conn:
            try:
                cursor = conn.cursor()
                # ✅ Sửa SoTinChi → TinChi, tên bảng HOCPHAN (không phải HocPhan)
                cursor.execute("SELECT MaHP, TenHP, TinChi FROM HOCPHAN")
                for row in cursor.fetchall(): self.tree_hp.insert("", tk.END, values=row)
            except Exception as e: messagebox.showerror("Lỗi", str(e))
            finally: conn.close()