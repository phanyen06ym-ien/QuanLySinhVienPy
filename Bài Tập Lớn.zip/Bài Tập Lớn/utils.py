import pyodbc
from tkinter import messagebox

def get_connection():
    """Kết nối đến SQL Server database"""
    try:
        return pyodbc.connect(
            r"Driver={SQL Server};"
            r"Server=.;"
            r"Database=QuanLySinhVien;"
            r"Trusted_Connection=yes;"
        )
    except Exception as e:
        messagebox.showerror("Lỗi kết nối", f"Không thể kết nối SQL: {e}")
        return None
