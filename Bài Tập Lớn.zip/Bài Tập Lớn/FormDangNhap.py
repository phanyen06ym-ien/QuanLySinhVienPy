from tkinter import *
from tkinter import messagebox
from FormGiangVien import LecturerForm
from FormSinhVien import StudentForm
from utils import get_connection

# ====== HÀM ĐĂNG NHẬP ======
def dang_nhap():
    u, p = entry_user.get(), entry_pass.get()
    conn = get_connection()
    if conn:
        cursor = conn.cursor()
        # Lấy quyền và ID tương ứng để mở đúng Form
        cursor.execute("SELECT VaiTro, MaSV, MaGV FROM TAIKHOAN WHERE MaTK=? AND PasswordHash=?", (u, p))
        row = cursor.fetchone()
        if row:
            vaitro, masv, magv = row
            window.withdraw()
            new_win = Toplevel()
            if vaitro == "GiangVien" or vaitro == "Admin":
                LecturerForm(new_win, magv if magv else "ADMIN", window, vaitro)
            else:
                StudentForm(new_win, masv, window)
        else:
            messagebox.showerror("Lỗi", "Sai tài khoản hoặc mật khẩu")
        conn.close()

# ====== HÀM ĐỔI MẬT KHẨU (QUÊN MẬT KHẨU) ======
def doi_mat_khau(u, p1, p2, win):
    if p1 != p2 or not p1:
        messagebox.showerror("Lỗi", "Mật khẩu không khớp hoặc trống!")
        return
    conn = get_connection()
    if conn:
        cursor = conn.cursor()
        cursor.execute("UPDATE TAIKHOAN SET PasswordHash=? WHERE MaTK=?", (p1, u))
        conn.commit()
        messagebox.showinfo("Thành công", "Đã đổi mật khẩu!")
        win.destroy()
        conn.close()

def mo_cua_so_quen_mk():
    forgot_win = Toplevel(window)
    forgot_win.title("Quên mật khẩu")
    forgot_win.geometry("300x200")
    Label(forgot_win, text="Tài khoản:").pack()
    en_u = Entry(forgot_win); en_u.pack()
    Label(forgot_win, text="Mật khẩu mới:").pack()
    en_p = Entry(forgot_win, show="*"); en_p.pack()
    Label(forgot_win, text="Nhập lại:").pack()
    en_p2 = Entry(forgot_win, show="*"); en_p2.pack()
    Button(forgot_win, text="Xác nhận", command=lambda: doi_mat_khau(en_u.get(), en_p.get(), en_p2.get(), forgot_win)).pack(pady=10)

# ====== HIỆN / ẨN MẬT KHẨU ======
def hien_mat_khau():
    if entry_pass.cget("show") == "*":
        entry_pass.config(show="")
    else:
        entry_pass.config(show="*")

# ====== GIAO DIỆN CHÍNH ======
window = Tk()
window.title("Đăng nhập")
window.geometry("400x300")

# Tiêu đề
Label(window, text="Quản Lý Sinh Viên", font=("Arial", 16, "bold")).pack(pady=20)

# Frame Form
frame = Frame(window)
frame.pack(pady=10)

Label(frame, text="Tài khoản:").grid(row=0, column=0, sticky="w", padx=5, pady=5)
entry_user = Entry(frame, width=25)
entry_user.grid(row=0, column=1, pady=5)

Label(frame, text="Mật khẩu:").grid(row=1, column=0, sticky="w", padx=5, pady=5)
entry_pass = Entry(frame, width=25, show="*")
entry_pass.grid(row=1, column=1, pady=5)

# Điều khiển
check = Checkbutton(window, text="Hiển thị mật khẩu", command=hien_mat_khau)
check.pack()

Button(window, text="Đăng nhập", width=15, bg="white", command=dang_nhap).pack(pady=10)

# Nút Quên mật khẩu
Button(window, text="Quên mật khẩu?", fg="blue", bd=0, cursor="hand2",
       command=mo_cua_so_quen_mk).pack()

window.mainloop()