import tkinter as tk
from tkinter import messagebox
from FormGiangVien import LecturerForm
from FormSinhVien import StudentForm
from FormAdmin import AdminForm
from utils import get_connection
# Form đăng nhập chính, xử lý logic xác thực và chuyển hướng đến các form tương ứng dựa trên vai trò người dùng
class LoginForm:
    def __init__(self, root):
        self.root = root
        self.root.title("Hệ Thống Quản Lý Đào Tạo - Đăng Nhập")
        self.root.geometry("450x350")
        self.root.resizable(False, False)

        # Tiêu đề chính
        tk.Label(root, text="QUẢN LÝ SINH VIÊN", font=("Arial", 18, "bold"), fg="#1e3a8a").pack(pady=25)

        # Khung chứa Form
        frame = tk.Frame(root)
        frame.pack(pady=10, padx=20)

        # Tài khoản
        tk.Label(frame, text="Tài khoản:", font=("Arial", 11)).grid(row=0, column=0, sticky="w", pady=8)
        self.entry_user = tk.Entry(frame, width=25, font=("Arial", 11))
        self.entry_user.grid(row=0, column=1, padx=10)
        self.entry_user.focus() # Tự động trỏ chuột vào ô nhập liệu

        # Mật khẩu
        tk.Label(frame, text="Mật khẩu:", font=("Arial", 11)).grid(row=1, column=0, sticky="w", pady=8)
        self.entry_pass = tk.Entry(frame, width=25, font=("Arial", 11), show="*")
        self.entry_pass.grid(row=1, column=1, padx=10)

        # Hiển thị mật khẩu
        self.show_pass_var = tk.IntVar()
        tk.Checkbutton(root, text="Hiển thị mật khẩu", variable=self.show_pass_var, 
                       command=self.toggle_pass).pack()

        # Nút Đăng nhập
        btn_login = tk.Button(root, text="ĐĂNG NHẬP", bg="#1e3a8a", fg="white", 
                             font=("Arial", 11, "bold"), width=20, height=1,
                             command=self.handle_login)
        btn_login.pack(pady=15)

        # Nút Quên mật khẩu
        tk.Button(root, text="Quên mật khẩu?", fg="#2563eb", bd=0, cursor="hand2",
                  command=self.open_forgot_pwd).pack()

    def toggle_pass(self):
        """Ẩn/hiện mật khẩu"""
        if self.show_pass_var.get() == 1:
            self.entry_pass.config(show="")
        else:
            self.entry_pass.config(show="*")

    def handle_login(self):
        """Xử lý logic đăng nhập và chuyển hướng Form"""
        username = self.entry_user.get().strip()
        password = self.entry_pass.get().strip()

        if not username or not password:
            messagebox.showwarning("Thông báo", "Vui lòng nhập đầy đủ tài khoản và mật khẩu!")
            return

        conn = get_connection()
        if conn:
            try:
                cursor = conn.cursor()
                # Truy vấn lấy thông tin vai trò và mã định danh
                query = "SELECT VaiTro, MaSV, MaGV FROM TAIKHOAN WHERE MaTK=? AND PasswordHash=?"
                cursor.execute(query, (username, password))
                row = cursor.fetchone()

                if row:
                    vaitro, masv, magv = row
                    self.root.withdraw()  # Ẩn cửa sổ đăng nhập
                    
                    # Tạo cửa sổ mới (Toplevel)
                    new_win = tk.Toplevel()
                    # Quan trọng: Nếu tắt cửa sổ con này, phải tắt toàn bộ ứng dụng (window.destroy)
                    new_win.protocol("WM_DELETE_WINDOW", lambda: self.root.destroy())

                    if vaitro == "GiangVien":
                        # Nếu magv bị None trong DB thì dùng username thay thế
                        LecturerForm(new_win, magv if magv else username, self.root, vaitro)
                    elif vaitro == "Admin":
                        AdminForm(new_win, username, self.root)
                    elif vaitro == "SinhVien":
                        StudentForm(new_win, masv if masv else username, self.root)
                    else:
                        messagebox.showerror("Lỗi", "Vai trò người dùng không hợp lệ!")
                        self.root.deiconify()
                else:
                    messagebox.showerror("Thất bại", "Tài khoản hoặc mật khẩu không chính xác!")
            except Exception as e:
                messagebox.showerror("Lỗi hệ thống", f"Lỗi truy vấn: {e}")
            finally:
                conn.close()

    def open_forgot_pwd(self):
        """Cửa sổ đổi mật khẩu nhanh"""
        forgot_win = tk.Toplevel(self.root)
        forgot_win.title("Khôi phục mật khẩu")
        forgot_win.geometry("350x250")
        
        tk.Label(forgot_win, text="Tài khoản:").pack(pady=5)
        en_u = tk.Entry(forgot_win); en_u.pack()
        
        tk.Label(forgot_win, text="Mật khẩu mới:").pack(pady=5)
        en_p1 = tk.Entry(forgot_win, show="*"); en_p1.pack()
        
        tk.Label(forgot_win, text="Xác nhận lại:").pack(pady=5)
        en_p2 = tk.Entry(forgot_win, show="*"); en_p2.pack()

        def confirm_change():
            u, p1, p2 = en_u.get(), en_p1.get(), en_p2.get()
            if p1 != p2 or not p1:
                messagebox.showerror("Lỗi", "Mật khẩu không khớp!")
                return
            
            conn = get_connection()
            if conn:
                cursor = conn.cursor()
                cursor.execute("UPDATE TAIKHOAN SET PasswordHash=? WHERE MaTK=?", (p1, u))
                conn.commit()
                messagebox.showinfo("Thành công", "Đã đổi mật khẩu!")
                forgot_win.destroy()
                conn.close()

        tk.Button(forgot_win, text="Xác nhận", bg="green", fg="white", 
                  command=confirm_change).pack(pady=15)

if __name__ == "__main__":
    root = tk.Tk()
    app = LoginForm(root)
    root.mainloop()