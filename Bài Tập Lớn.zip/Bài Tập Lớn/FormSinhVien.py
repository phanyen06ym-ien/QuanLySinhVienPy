import tkinter as tk
from tkinter import ttk, messagebox
from utils import get_connection

class StudentForm:
    def __init__(self, root, ma_sv, login_win):
        self.root, self.login_win, self.ma_sv = root, login_win, ma_sv
        self.root.title(f"Sinh viên: {ma_sv}")
        self.root.geometry("800x500")

        tk.Button(self.root, text="Đăng xuất", bg="red", fg="black", command=self.dang_xuat).pack(anchor="ne", padx=10)

        self.tabs = ttk.Notebook(self.root)
        self.tabs.pack(fill=tk.BOTH, expand=True)

        # Tab Thông tin cá nhân
        self.tab_i = tk.Frame(self.tabs); self.tabs.add(self.tab_i, text="Thông tin cá nhân")
        self.load_info()

        # Tab Xem kết quả học tập
        self.tab_g = tk.Frame(self.tabs); self.tabs.add(self.tab_g, text="Kết quả học tập")
        self.load_grades()

        # Tab Đăng ký học tập
        self.tab_r = tk.Frame(self.tabs); self.tabs.add(self.tab_r, text="Đăng ký học tập")
        self.load_registration()

    def load_info(self):
        conn = get_connection()
        if conn:
            try:
                cursor = conn.cursor()
                cursor.execute("SELECT HoTen, NgaySinh, DiaChi FROM SINHVIEN WHERE MaSV=?", (self.ma_sv,))
                res = cursor.fetchone()
                if res:
                    tk.Label(self.tab_i, text=f"Họ tên: {res[0]}", font=("Arial", 12)).pack(pady=10)
                    tk.Label(self.tab_i, text=f"Ngày sinh: {res[1]}").pack()
                    tk.Label(self.tab_i, text=f"Địa chỉ: {res[2]}").pack()
                else:
                    tk.Label(self.tab_i, text="Không tìm thấy thông tin sinh viên", fg="red").pack(pady=20)
            except Exception as e:
                messagebox.showerror("Lỗi", f"Lỗi tải thông tin: {e}")
            finally:
                conn.close()
        else:
            tk.Label(self.tab_i, text="Không thể kết nối database", fg="red").pack(pady=20)

    def load_grades(self):
        # Tạo Treeview để hiển thị kết quả học tập
        self.tree_grades = ttk.Treeview(self.tab_g, columns=("mahp", "tenhp", "diem"), show="headings")
        self.tree_grades.heading("mahp", text="Mã HP")
        self.tree_grades.heading("tenhp", text="Tên HP")
        self.tree_grades.heading("diem", text="Điểm")
        self.tree_grades.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # Load dữ liệu điểm
        conn = get_connection()
        if conn:
            try:
                cursor = conn.cursor()
                cursor.execute("""
                    SELECT HocPhan.MaHP, HocPhan.TenHP, KetQua.Diem
                    FROM KetQua
                    JOIN HocPhan ON KetQua.MaHP = HocPhan.MaHP
                    WHERE KetQua.MaSV = ?
                """, (self.ma_sv,))
                rows = cursor.fetchall()
                for row in rows:
                    self.tree_grades.insert("", tk.END, values=row)
            except Exception as e:
                messagebox.showerror("Lỗi", f"Lỗi tải kết quả học tập: {e}")
            finally:
                conn.close()

    def load_registration(self):
        # Tạo Treeview để hiển thị danh sách học phần có thể đăng ký
        self.tree_reg = ttk.Treeview(self.tab_r, columns=("mahp", "tenhp", "sotin"), show="headings")
        self.tree_reg.heading("mahp", text="Mã HP")
        self.tree_reg.heading("tenhp", text="Tên HP")
        self.tree_reg.heading("sotin", text="Số tín")
        self.tree_reg.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # Button đăng ký
        tk.Button(self.tab_r, text="Đăng ký học phần đã chọn", bg="green", fg="white",
                 command=self.register_course).pack(pady=10)

        # Load danh sách học phần
        conn = get_connection()
        if conn:
            try:
                cursor = conn.cursor()
                cursor.execute("SELECT MaHP, TenHP, SoTinChi FROM HocPhan")
                rows = cursor.fetchall()
                for row in rows:
                    self.tree_reg.insert("", tk.END, values=row)
            except Exception as e:
                messagebox.showerror("Lỗi", f"Lỗi tải danh sách học phần: {e}")
            finally:
                conn.close()

    def register_course(self):
        selected = self.tree_reg.selection()
        if not selected:
            messagebox.showwarning("Cảnh báo", "Vui lòng chọn học phần để đăng ký!")
            return

        item = self.tree_reg.item(selected[0])
        mahp = item['values'][0]

        conn = get_connection()
        if conn:
            try:
                cursor = conn.cursor()
                # Kiểm tra đã đăng ký chưa
                cursor.execute("SELECT * FROM DangKy WHERE MaSV=? AND MaHP=?", (self.ma_sv, mahp))
                if cursor.fetchone():
                    messagebox.showwarning("Cảnh báo", "Bạn đã đăng ký học phần này!")
                    return

                # Đăng ký học phần
                cursor.execute("INSERT INTO DangKy (MaSV, MaHP, NgayDangKy) VALUES (?, ?, GETDATE())",
                             (self.ma_sv, mahp))
                conn.commit()
                messagebox.showinfo("Thành công", "Đăng ký học phần thành công!")
            except Exception as e:
                messagebox.showerror("Lỗi", f"Lỗi đăng ký: {e}")
            finally:
                conn.close()

    def dang_xuat(self):
        self.root.destroy()
        self.login_win.deiconify()