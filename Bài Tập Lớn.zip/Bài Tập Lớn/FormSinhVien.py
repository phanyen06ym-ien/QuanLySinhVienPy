import tkinter as tk
from tkinter import ttk, messagebox
from utils import get_connection

class StudentForm:
    def __init__(self, root, ma_sv, login_win):
        self.root, self.login_win, self.ma_sv = root, login_win, ma_sv
        self.root.title(f"Sinh viên: {ma_sv}")
        self.root.geometry("850x580")

        tk.Button(self.root, text="Đăng xuất", bg="red", fg="white",
                  command=self.dang_xuat).pack(anchor="ne", padx=10, pady=5)

        self.tabs = ttk.Notebook(self.root)
        self.tabs.pack(fill=tk.BOTH, expand=True)

        self.tab_i = tk.Frame(self.tabs); self.tabs.add(self.tab_i, text="Thông tin cá nhân")
        self.tab_g = tk.Frame(self.tabs); self.tabs.add(self.tab_g, text="Kết quả học tập")
        self.tab_r = tk.Frame(self.tabs); self.tabs.add(self.tab_r, text="Đăng ký môn học")

        self.load_info()
        self.ui_grades()
        self.ui_registration()

    def load_info(self):
        conn = get_connection()
        if conn:
            try:
                cursor = conn.cursor()
                # ✅ Lấy thêm MaLop, GioiTinh, SDT, NamThu, KhoaHoc từ SINHVIEN
                cursor.execute("""
                    SELECT sv.HoTen, sv.NgaySinh, sv.DiaChi, sv.GioiTinh,
                           sv.SDT, sv.MaLop, sv.NamThu, sv.KhoaHoc
                    FROM SINHVIEN sv
                    WHERE sv.MaSV = ?
                """, (self.ma_sv,))
                res = cursor.fetchone()
                if res:
                    fields = [
                        ("Mã SV",       self.ma_sv),
                        ("Họ tên",       res[0]),
                        ("Ngày sinh",    res[1]),
                        ("Giới tính",    res[3]),
                        ("SĐT",          res[4]),
                        ("Địa chỉ",      res[2]),
                        ("Mã lớp",       res[5]),
                        ("Năm thứ",      res[6]),
                        ("Khóa học",     res[7]),
                    ]
                    for label, val in fields:
                        tk.Label(self.tab_i,
                                 text=f"{label}: {val}",
                                 font=("Arial", 11),
                                 anchor="w").pack(padx=20, pady=2, fill="x")
                else:
                    tk.Label(self.tab_i, text="Không tìm thấy thông tin sinh viên",
                             fg="red").pack(pady=20)
            except Exception as e:
                messagebox.showerror("Lỗi", f"Lỗi tải thông tin: {e}")
            finally:
                conn.close()

    def ui_grades(self):
        # ✅ Hiển thị đầy đủ các cột điểm từ BANGDIEM
        cols = ("mahp","tenhp","hk","nh","cc","bt","gk","ck","tk")
        headers = ["Mã HP","Tên HP","HK","Năm học","CC","BT","GK","CK","Tổng kết"]
        self.tree_grades = ttk.Treeview(self.tab_g, columns=cols, show="headings")
        for col, h in zip(cols, headers):
            self.tree_grades.heading(col, text=h)
            self.tree_grades.column(col, width=80)
        self.tree_grades.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        tk.Button(self.tab_g, text="Làm mới", command=self.load_grades).pack()
        self.load_grades()

    def load_grades(self):
        for item in self.tree_grades.get_children(): self.tree_grades.delete(item)
        conn = get_connection()
        if conn:
            try:
                cursor = conn.cursor()
                # ✅ Query từ BANGDIEM (không phải KetQua), join với HOCPHAN
                cursor.execute("""
                    SELECT B.MaHP, H.TenHP, B.HocKy, B.NamHoc,
                           B.DiemChuyenCan, B.DiemBaiTap,
                           B.DiemGiuaKy, B.DiemCuoiKy, B.DiemTongKet
                    FROM BANGDIEM B
                    JOIN HOCPHAN H ON B.MaHP = H.MaHP
                    WHERE B.MaSV = ?
                    ORDER BY B.NamHoc, B.HocKy
                """, (self.ma_sv,))
                for row in cursor.fetchall():
                    self.tree_grades.insert("", tk.END, values=row)
            except Exception as e:
                messagebox.showerror("Lỗi", f"Lỗi tải kết quả: {e}")
            finally:
                conn.close()

    def ui_registration(self):
        # Frame chọn học kỳ / năm học trước khi đăng ký
        f = tk.Frame(self.tab_r); f.pack(pady=8)
        tk.Label(f, text="Học kỳ:").grid(row=0, column=0, padx=5)
        self.ent_hocky = ttk.Combobox(f, values=["1","2","3"], width=8)
        self.ent_hocky.grid(row=0, column=1, padx=5)
        self.ent_hocky.current(0)

        tk.Label(f, text="Năm học:").grid(row=0, column=2, padx=5)
        self.ent_namhoc = tk.Entry(f, width=12); self.ent_namhoc.grid(row=0, column=3, padx=5)
        self.ent_namhoc.insert(0, "2024-2025")

        self.tree_reg = ttk.Treeview(self.tab_r, columns=("1","2","3"), show="headings")
        for i, txt in enumerate(["Mã HP","Tên HP","Số tín chỉ"], 1):
            self.tree_reg.heading(str(i), text=txt)
        self.tree_reg.pack(fill=tk.BOTH, expand=True, padx=10)

        tk.Button(self.tab_r, text="Đăng ký học phần đã chọn",
                  bg="green", fg="white", command=self.register_course).pack(pady=5)
        self.load_all_courses()

    def load_all_courses(self):
        conn = get_connection()
        if conn:
            try:
                cursor = conn.cursor()
                # ✅ TinChi (không phải SoTinChi), bảng HOCPHAN
                cursor.execute("SELECT MaHP, TenHP, TinChi FROM HOCPHAN")
                for row in cursor.fetchall():
                    self.tree_reg.insert("", tk.END, values=row)
            except Exception as e:
                messagebox.showerror("Lỗi", f"Lỗi tải danh sách học phần: {e}")
            finally:
                conn.close()

    def register_course(self):
        sel = self.tree_reg.selection()
        if not sel:
            messagebox.showwarning("Cảnh báo", "Vui lòng chọn học phần để đăng ký!")
            return

        ma_hp  = self.tree_reg.item(sel[0])['values'][0]
        hocky  = self.ent_hocky.get().strip()
        namhoc = self.ent_namhoc.get().strip()

        if not hocky or not namhoc:
            messagebox.showwarning("Cảnh báo", "Vui lòng chọn Học kỳ và Năm học!")
            return

        conn = get_connection()
        if conn:
            try:
                cursor = conn.cursor()
                # ✅ Kiểm tra trùng theo đúng PK(MaSV, MaHP, HocKy, NamHoc)
                cursor.execute("""
                    SELECT 1 FROM DANGKY
                    WHERE MaSV=? AND MaHP=? AND HocKy=? AND NamHoc=?
                """, (self.ma_sv, ma_hp, hocky, namhoc))
                if cursor.fetchone():
                    messagebox.showwarning("Cảnh báo", "Bạn đã đăng ký môn này trong học kỳ này rồi!")
                    return

                # ✅ INSERT đủ 4 cột PK bắt buộc
                cursor.execute("""
                    INSERT INTO DANGKY (MaSV, MaHP, HocKy, NamHoc)
                    VALUES (?, ?, ?, ?)
                """, (self.ma_sv, ma_hp, hocky, namhoc))
                conn.commit()
                messagebox.showinfo("Thành công", f"Đã đăng ký môn {ma_hp} - HK{hocky} {namhoc}")
            except Exception as e:
                messagebox.showerror("Lỗi đăng ký", f"Lỗi: {e}")
            finally:
                conn.close()

    def dang_xuat(self):
        self.root.destroy()
        self.login_win.deiconify()