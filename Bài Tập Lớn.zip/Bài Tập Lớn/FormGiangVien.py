import tkinter as tk
from tkinter import ttk, messagebox
import pyodbc
from utils import get_connection

class LecturerForm:
    def __init__(self, root, ma_id, login_win, role):
        self.root, self.login_win, self.ma_id, self.role = root, login_win, ma_id, role
        self.root.title(f"Quản lý - {role}: {ma_id}")
        self.root.geometry("1000x600")

        tk.Button(self.root, text="Đăng xuất", bg="red", fg="black", command=self.dang_xuat).pack(anchor="ne", padx=10)
        
        self.tabs = ttk.Notebook(self.root)
        self.tabs.pack(fill=tk.BOTH, expand=True)

        # 1. Tab Lớp phụ trách
        self.tab1 = tk.Frame(self.tabs); self.tabs.add(self.tab1, text="Lớp phụ trách")
        self.tree_lop = ttk.Treeview(self.tab1, columns=("ma", "ten"), show="headings")
        self.tree_lop.heading("ma", text="Mã Lớp"); self.tree_lop.heading("ten", text="Tên Lớp"); self.tree_lop.pack(fill=tk.BOTH)

        # 2. Tab Nhập điểm
        self.tab2 = tk.Frame(self.tabs); self.tabs.add(self.tab2, text="Nhập/Sửa điểm")
        # (Thêm các Entry nhập mã SV, mã HP, và điểm tại đây giống như code bạn đã có)

        # 3. Tab Quản lý danh sách lớp (Chỉ Admin/GV có quyền)
        self.tab3 = tk.Frame(self.tabs); self.tabs.add(self.tab3, text="Quản lý lớp học")
        self.ui_quan_ly_ds()

    def ui_quan_ly_ds(self):
        f = tk.Frame(self.tab3); f.pack(pady=10)
        tk.Label(f, text="Mã SV:").grid(row=0, column=0)
        self.ent_sv = tk.Entry(f); self.ent_sv.grid(row=0, column=1)
        tk.Label(f, text="Mã Lớp:").grid(row=0, column=2)
        self.ent_l = tk.Entry(f); self.ent_l.grid(row=0, column=3)
        
        tk.Button(f, text="Thêm SV", command=self.add_sv).grid(row=1, column=0)
        tk.Button(f, text="Xóa SV", command=self.del_sv).grid(row=1, column=1)
        tk.Button(f, text="Chuyển lớp", command=self.move_sv).grid(row=1, column=2)

    def add_sv(self): # Logic thêm sinh viên vào database
        pass 

    def dang_xuat(self):
        self.root.destroy(); self.login_win.deiconify()