import tkinter as tk
from tkinter import ttk, messagebox
from utils import get_connection

class LecturerForm:
    def __init__(self, root, ma_id, login_win, role):
        self.root, self.login_win, self.ma_id, self.role = root, login_win, ma_id, role
        self.root.title(f"Giảng Viên: {ma_id}")
        self.root.geometry("1000x620")

        tk.Button(self.root, text="Đăng xuất", bg="red", fg="white",
                  command=self.dang_xuat).pack(anchor="ne", padx=10, pady=5)

        self.tabs = ttk.Notebook(self.root)
        self.tabs.pack(fill=tk.BOTH, expand=True)

        # Tab 1: Lớp phụ trách
        self.tab1 = tk.Frame(self.tabs); self.tabs.add(self.tab1, text="Lớp phụ trách")
        self.tree_lop = ttk.Treeview(self.tab1, columns=("ma","ten","nganh"), show="headings")
        self.tree_lop.heading("ma", text="Mã Lớp")
        self.tree_lop.heading("ten", text="Tên Lớp")
        self.tree_lop.heading("nganh", text="Chuyên ngành")
        self.tree_lop.pack(fill=tk.BOTH, expand=True, padx=10)
        tk.Button(self.tab1, text="Xem danh sách lớp", command=self.load_classes).pack(pady=5)

        # Tab 2: Nhập điểm — khớp với bảng BANGDIEM
        self.tab2 = tk.Frame(self.tabs); self.tabs.add(self.tab2, text="Nhập/Sửa điểm")
        self.ui_nhap_diem()

    def ui_nhap_diem(self):
        f = tk.Frame(self.tab2); f.pack(pady=15)

        tk.Label(f, text="Mã SV:").grid(row=0, column=0, padx=5, pady=4)
        self.ent_msv = tk.Entry(f, width=15); self.ent_msv.grid(row=0, column=1, padx=5)

        tk.Label(f, text="Mã HP:").grid(row=0, column=2, padx=5)
        self.ent_mhp = tk.Entry(f, width=15); self.ent_mhp.grid(row=0, column=3, padx=5)

        # ✅ BANGDIEM cần HocKy + NamHoc để xác định đúng bản ghi
        tk.Label(f, text="Học kỳ:").grid(row=1, column=0, padx=5, pady=4)
        self.ent_hocky = ttk.Combobox(f, values=["1","2","3"], width=12)
        self.ent_hocky.grid(row=1, column=1, padx=5)

        tk.Label(f, text="Năm học:").grid(row=1, column=2, padx=5)
        self.ent_namhoc = tk.Entry(f, width=15); self.ent_namhoc.grid(row=1, column=3, padx=5)
        self.ent_namhoc.insert(0, "2024-2025")

        # ✅ 4 cột điểm theo đúng cấu trúc BANGDIEM
        tk.Label(f, text="CC (5%):").grid(row=2, column=0, padx=5, pady=4)
        self.ent_cc = tk.Entry(f, width=10); self.ent_cc.grid(row=2, column=1, padx=5)

        tk.Label(f, text="BT (15%):").grid(row=2, column=2, padx=5)
        self.ent_bt = tk.Entry(f, width=10); self.ent_bt.grid(row=2, column=3, padx=5)

        tk.Label(f, text="GK (20%):").grid(row=3, column=0, padx=5, pady=4)
        self.ent_gk = tk.Entry(f, width=10); self.ent_gk.grid(row=3, column=1, padx=5)

        tk.Label(f, text="CK (60%):").grid(row=3, column=2, padx=5)
        self.ent_ck = tk.Entry(f, width=10); self.ent_ck.grid(row=3, column=3, padx=5)

        tk.Button(f, text="Lưu điểm", bg="blue", fg="white",
                  command=self.update_grade).grid(row=4, column=0, columnspan=4, pady=10)

        # Bảng xem điểm
        self.tree_diem = ttk.Treeview(self.tab2,
            columns=("masv","mahp","hk","nh","cc","bt","gk","ck","tk"), show="headings")
        headers = ["Mã SV","Mã HP","HK","Năm học","CC","BT","GK","CK","Tổng kết"]
        for col, h in zip(("masv","mahp","hk","nh","cc","bt","gk","ck","tk"), headers):
            self.tree_diem.heading(col, text=h)
            self.tree_diem.column(col, width=80)
        self.tree_diem.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        tk.Button(self.tab2, text="Tải bảng điểm lớp", command=self.load_grades).pack(pady=3)

    def load_classes(self):
        for item in self.tree_lop.get_children(): self.tree_lop.delete(item)
        conn = get_connection()
        if conn:
            try:
                cursor = conn.cursor()
                # ✅ Bảng tên LOPHOC, cố vấn học tập là CoVanHocTap (= MaGV)
                cursor.execute("""
                    SELECT MaLop, TenLop, ChuyenNganh
                    FROM LOPHOC
                    WHERE CoVanHocTap = ?
                """, (self.ma_id,))
                for row in cursor.fetchall():
                    self.tree_lop.insert("", tk.END, values=row)
            except Exception as e:
                messagebox.showerror("Lỗi", f"Lỗi tải danh sách lớp: {e}")
            finally:
                conn.close()

    def update_grade(self):
        msv   = self.ent_msv.get().strip()
        mhp   = self.ent_mhp.get().strip()
        hocky = self.ent_hocky.get().strip()
        namhoc= self.ent_namhoc.get().strip()
        cc    = self.ent_cc.get().strip()
        bt    = self.ent_bt.get().strip()
        gk    = self.ent_gk.get().strip()
        ck    = self.ent_ck.get().strip()

        if not all([msv, mhp, hocky, namhoc]):
            return messagebox.showwarning("Lỗi", "Vui lòng nhập đủ Mã SV, Mã HP, Học kỳ, Năm học!")

        # Validate điểm nếu có nhập
        diem_map = {"CC": cc, "BT": bt, "GK": gk, "CK": ck}
        for ten, val in diem_map.items():
            if val:
                try:
                    d = float(val)
                    if not (0 <= d <= 10):
                        return messagebox.showerror("Lỗi", f"Điểm {ten} phải từ 0 đến 10!")
                except ValueError:
                    return messagebox.showerror("Lỗi", f"Điểm {ten} phải là số!")

        conn = get_connection()
        if conn:
            try:
                cursor = conn.cursor()
                # ✅ Kiểm tra đã có bản ghi trong BANGDIEM chưa (PK gồm 4 cột)
                cursor.execute("""
                    SELECT 1 FROM BANGDIEM
                    WHERE MaSV=? AND MaHP=? AND HocKy=? AND NamHoc=?
                """, (msv, mhp, hocky, namhoc))

                if cursor.fetchone():
                    # UPDATE nếu đã có
                    cursor.execute("""
                        UPDATE BANGDIEM
                        SET DiemChuyenCan=?, DiemBaiTap=?, DiemGiuaKy=?, DiemCuoiKy=?
                        WHERE MaSV=? AND MaHP=? AND HocKy=? AND NamHoc=?
                    """, (cc or None, bt or None, gk or None, ck or None,
                          msv, mhp, hocky, namhoc))
                else:
                    # INSERT nếu chưa có
                    cursor.execute("""
                        INSERT INTO BANGDIEM (MaSV, MaHP, HocKy, NamHoc,
                            DiemChuyenCan, DiemBaiTap, DiemGiuaKy, DiemCuoiKy)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """, (msv, mhp, hocky, namhoc,
                          cc or None, bt or None, gk or None, ck or None))

                conn.commit()
                messagebox.showinfo("Thành công", "Đã lưu điểm!")
                self.load_grades()
            except Exception as e:
                messagebox.showerror("Lỗi SQL", str(e))
            finally:
                conn.close()

    def load_grades(self):
        for item in self.tree_diem.get_children(): self.tree_diem.delete(item)
        msv = self.ent_msv.get().strip()
        conn = get_connection()
        if conn:
            try:
                cursor = conn.cursor()
                if msv:
                    cursor.execute("""
                        SELECT MaSV, MaHP, HocKy, NamHoc,
                               DiemChuyenCan, DiemBaiTap, DiemGiuaKy, DiemCuoiKy, DiemTongKet
                        FROM BANGDIEM WHERE MaSV=?
                    """, (msv,))
                else:
                    cursor.execute("""
                        SELECT MaSV, MaHP, HocKy, NamHoc,
                               DiemChuyenCan, DiemBaiTap, DiemGiuaKy, DiemCuoiKy, DiemTongKet
                        FROM BANGDIEM
                    """)
                for row in cursor.fetchall():
                    self.tree_diem.insert("", tk.END, values=row)
            except Exception as e:
                messagebox.showerror("Lỗi", str(e))
            finally:
                conn.close()

    def dang_xuat(self):
        self.root.destroy()
        self.login_win.deiconify()